+++
title = 'Primis eget imperdiet lorem'
slug = 'post1'
image = 'images/pic03.jpg'
description = 'Example of post with missing date property but with pic.'
disableComments = true
+++
Example of post with missing date property but with pic.

![img](/images/pic03.jpg)
