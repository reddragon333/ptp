+++
slug = 'plan'
description = 'Выберите поездку из календаря'
disableComments = true
+++
{{< rawhtml >}}
<div data-tockify-component="calendar" data-tockify-calendar="testcalendar1111tqtq">
</div>
<script data-cfasync="false" data-tockify-script="embed" src="https://public.tockify.com/browser/embed.js">
</script>
{{< /rawhtml >}}


{{< rawhtml >}}
<div data-tockify-component="mini" data-tockify-calendar="testcalendar1111tqtq">
</div>
<script data-cfasync="false" data-tockify-script="embed" src="https://public.tockify.com/browser/embed.js">
</script>
{{< /rawhtml >}}

{{< rawhtml >}}
<script src="https://api-maps.yandex.ru/2.1/?apikey=316b18fe-0f3b-45d3-8930-26eafd8c0beb&lang=ru_RU&load=Geolink"
 type="text/javascript"></script>
 <span class="ymaps-geolink">
   Москва, ул. Крылатские холмы, 26
</span>
{{< /rawhtml >}}

{{< rawhtml >}}
<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A310cf72dabd996de0f1c262455693604c6870c63c39df27000697a86f5fcd8c9&amp;width=100%25&amp;height=633&amp;lang=ru_RU&amp;scroll=true;apikey=316b18fe-0f3b-45d3-8930-26eafd8c0beb"></script>
{{< /rawhtml >}}