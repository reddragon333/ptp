+++
title = 'Карта поездок'
slug = 'map'
# image = 'images/pic02.jpg'
# description = 'здесь можно добавить подпись'
disableComments = true
+++

{{< rawhtml >}}
<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A310cf72dabd996de0f1c262455693604c6870c63c39df27000697a86f5fcd8c9&amp;width=100%25&amp;height=633&amp;lang=ru_RU&amp;scroll=true;apikey=316b18fe-0f3b-45d3-8930-26eafd8c0beb"></script>
{{< /rawhtml >}}