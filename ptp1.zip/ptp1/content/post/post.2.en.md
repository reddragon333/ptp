+++
title = 'Суздаль'
slug = 'post2'
image = 'images/pic04.jpg'
date = "2019-04-18T00:00:00"
description = 'Сказочный город Суздаль'
disableComments = true
+++


Суздаль. Погуляйте по улицам с деревянными домиками, посетите Суздальский Кремль и Золотую кладовую, поближе познакомьтесь с бытом наших предков в музее деревянного зодчества. А уж какие тут продаются огурчики — не захочешь, а купишь, так умеют нахваливать свой товар местные жители. Посмотрите наш маршрут прогулки по Суздалю.

{{< rawhtml >}}
<script src="https://api-maps.yandex.ru/2.1/?apikey=316b18fe-0f3b-45d3-8930-26eafd8c0beb&lang=ru_RU&load=Geolink"
 type="text/javascript"></script>
 <span class="ymaps-geolink">
   Москва, ул. Крылатские холмы, 26
</span>
{{< /rawhtml >}}