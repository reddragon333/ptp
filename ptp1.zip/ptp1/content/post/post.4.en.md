+++
title = 'Кострома'
slug = 'post4'
image = 'images/pic06.jpg'
date = "2019-04-11T00:00:00"
description = 'Donec eget ex magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Pellentesque venenatis dolor imperdiet dolor mattis sagittis magna etiam.'
disableComments = true
+++

{{< rawhtml >}}
<script async src="https://telegram.org/js/telegram-widget.js?21" data-telegram-post="whilesleeping/319" data-width="100%"></script>
{{< /rawhtml >}}

Кострома
Тихий и уютный город понравится любителям русской старины. Чего только стоит Ипатьевский монастырь 14 столетия, местный этнографический музей и сказочный терем белолицей Снегурочки! Узнайте, что посмотреть в Костроме. 