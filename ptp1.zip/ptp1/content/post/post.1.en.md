+++
title = 'Primis eget imperdiet lorem'
slug = 'post1'
image = 'images/pic03.jpg'
description = 'Милый город Суздаль'
disableComments = true
+++
Example of post with missing date property but with pic.

![img](/images/pic03.jpg)

Суздаль. Погуляйте по улицам с деревянными домиками, посетите Суздальский Кремль и Золотую кладовую, поближе познакомьтесь с бытом наших предков в музее деревянного зодчества. А уж какие тут продаются огурчики — не захочешь, а купишь, так умеют нахваливать свой товар местные жители. Посмотрите наш маршрут прогулки по Суздалю.

{{< rawhtml >}}
<script src="https://api-maps.yandex.ru/2.1/?apikey=316b18fe-0f3b-45d3-8930-26eafd8c0beb&lang=ru_RU&load=Geolink"
 type="text/javascript"></script>
 <span class="ymaps-geolink">
   Москва, ул. Крылатские холмы, 26
</span>
{{< /rawhtml >}}